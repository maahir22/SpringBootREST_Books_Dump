package com.he.he.services;
import com.he.he.entity.Course;
public interface CourseService {
	public Course getCourse(int id);
	public Course addCourse(Course course);
}
